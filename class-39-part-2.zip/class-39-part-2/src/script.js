const mybutton=document.getElementById("mybutton");
mybutton.addEventListener("click",function(){
  var a=document.getElementById("date1").value;
  var b=document.getElementById("date2").value;
  var datei1=new Date(a);
  var datei2=new Date(b);
  var timedifference=datei2.getTime()-datei1.getTime();
  var result=document.getElementById("result");
  result.innerHTML=timedifference/(24*60*60*1000)+" days apart";
})