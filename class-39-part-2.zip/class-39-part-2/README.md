# class 39 part 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/Krishay-Menon/pen/gOEYZjV](https://codepen.io/Krishay-Menon/pen/gOEYZjV).

